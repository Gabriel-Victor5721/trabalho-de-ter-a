import React, { useState } from "react";
import { View, Text, TextInput, Button } from "react-native";
import { atualizarMaterial } from "../storage/materialStorage";

export default function EditMaterialScreen({ route, navigation }) {
  const { material } = route.params;

  const [titulo, setTitulo] = useState(material.titulo);
  const [descricao, setDescricao] = useState(material.descricao);

  const salvar = async () => {
    await atualizarMaterial(material.id, titulo, descricao);
    navigation.goBack();
  };

  return (
    <View style={{ padding: 20 }}>
      <Text>Editar Material</Text>

      <TextInput
        value={titulo}
        onChangeText={setTitulo}
        placeholder="Título"
        style={{ marginVertical: 10, borderWidth: 1, padding: 8 }}
      />

      <TextInput
        value={descricao}
        onChangeText={setDescricao}
        placeholder="Descrição"
        style={{ marginVertical: 10, borderWidth: 1, padding: 8 }}
      />

      <Button title="Salvar" onPress={salvar} />
    </View>
  );
}
