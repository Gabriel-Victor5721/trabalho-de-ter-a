import React, { useState } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import { salvarMaterial } from '../storage/materialStorage';

export default function AddMaterialScreen({ navigation }) {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [link, setLink] = useState('');

  const salvar = async () => {
    if (titulo.trim() === '') return;

    await salvarMaterial({
      titulo,
      descricao,
      link
    });

    navigation.goBack();
  };

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Novo Material</Text>

      <TextInput
        placeholder="Título"
        style={{ backgroundColor: '#EEE', padding: 10, borderRadius: 8, marginBottom: 10 }}
        value={titulo}
        onChangeText={setTitulo}
      />

      <TextInput
        placeholder="Descrição"
        style={{ backgroundColor: '#EEE', padding: 10, borderRadius: 8, marginBottom: 10 }}
        value={descricao}
        onChangeText={setDescricao}
      />

      <TextInput
        placeholder="Link / URL"
        style={{ backgroundColor: '#EEE', padding: 10, borderRadius: 8, marginBottom: 10 }}
        value={link}
        onChangeText={setLink}
      />

      <Button title="Salvar" onPress={salvar} />
    </View>
  );
}
