import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const login = async () => {
    const usuarioSalvo = await AsyncStorage.getItem("usuario");

    if (!usuarioSalvo) {
      Alert.alert("Erro", "Nenhum usuário cadastrado!");
      return;
    }

    const usuario = JSON.parse(usuarioSalvo);

    if (usuario.email === email && usuario.senha === senha) {
      navigation.replace("Home");
    } else {
      Alert.alert("Erro", "E-mail ou senha incorretos");
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", padding: 20 }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Login</Text>

      <TextInput
        placeholder="E-mail"
        value={email}
        onChangeText={setEmail}
        style={{ borderWidth: 1, padding: 10, marginBottom: 15, borderRadius: 8 }}
      />

      <TextInput
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        style={{ borderWidth: 1, padding: 10, marginBottom: 15, borderRadius: 8 }}
      />

      <Button title="Entrar" onPress={login} />

      <View style={{ marginTop: 20 }}>
        <Button
          title="Criar Conta"
          onPress={() => navigation.navigate("Register")}
        />
      </View>
    </View>
  );
}
