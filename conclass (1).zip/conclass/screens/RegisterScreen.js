import React, { useState } from "react";
import { View, Text, TextInput, Button, Alert } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function RegisterScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const registrar = async () => {
    if (!email || !senha) {
      Alert.alert("Erro", "Preencha todos os campos!");
      return;
    }

    const usuario = { email, senha };

    await AsyncStorage.setItem("usuario", JSON.stringify(usuario));

    Alert.alert("Sucesso", "Conta criada com sucesso!");
    navigation.replace("Login");
  };

  return (
    <View style={{ flex: 1, padding: 20, justifyContent: "center" }}>
      <Text style={{ fontSize: 24, marginBottom: 20 }}>Criar Conta</Text>

      <TextInput
        placeholder="E-mail"
        value={email}
        onChangeText={setEmail}
        style={{
          borderWidth: 1,
          padding: 10,
          marginBottom: 15,
          borderRadius: 8
        }}
      />

      <TextInput
        placeholder="Senha"
        secureTextEntry
        value={senha}
        onChangeText={setSenha}
        style={{
          borderWidth: 1,
          padding: 10,
          marginBottom: 15,
          borderRadius: 8
        }}
      />

      <Button title="Registrar" onPress={registrar} />

      <View style={{ marginTop: 20 }}>
        <Button
          title="Já tenho conta"
          onPress={() => navigation.replace("Login")}
        />
      </View>
    </View>
  );
}
