import { View, Text, Button, Linking, Alert } from 'react-native';

export default function AulaScreen({ route }) {
  const { material } = route.params;

  const abrirLink = () => {
    if (!material.link) {
      Alert.alert("Erro", "Nenhum link foi encontrado.");
      return;
    }

    // Verifica se o link é válido
    const url = material.link.startsWith("http")
      ? material.link
      : "https://" + material.link;

    Linking.openURL(url).catch(() => {
      Alert.alert("Erro", "Não foi possível abrir o link.");
    });
  };

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 26, fontWeight: 'bold' }}>
        {material.titulo}
      </Text>

      <Text style={{ marginTop: 10, fontSize: 16 }}>
        {material.descricao}
      </Text>

      <View style={{ marginTop: 20 }}>
        <Button title="Abrir Material" onPress={abrirLink} />
      </View>
    </View>
  );
}
