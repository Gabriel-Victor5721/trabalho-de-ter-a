import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, Button, Alert } from 'react-native';
import { obterMateriais, removerMaterial } from '../storage/materialStorage';
import MaterialCard from '../components/MaterialCard';
import Header from '../components/Header';
import LogoutButton from "../components/LogoutButton";

export default function HomeScreen({ navigation }) {
  const [materiais, setMateriais] = useState([]);

  const carregar = async () => {
    const data = await obterMateriais();
    setMateriais(data);
  };

  useEffect(() => {
    const focus = navigation.addListener("focus", carregar);
    return focus;
  }, []);

  const handleDelete = (id, titulo) => {
    Alert.alert(
      "Excluir Material",
      `Deseja excluir a matéria: "${titulo}"?`,
      [
        { text: "Cancelar", style: "cancel" },
        {
          text: "Excluir",
          style: "destructive",
          onPress: async () => {
            await removerMaterial(id);
            carregar();
          }
        }
      ]
    );
  };

  return (
    <View style={{ flex: 1 }}>

      <Header title="Materiais Disponíveis" />

      
      <View style={{ flex: 1, padding: 20 }}>

        <Button
          title="Adicionar Novo Material"
          onPress={() => navigation.navigate("AddMaterial")}
        />

        <ScrollView style={{ marginTop: 20 }}>
          {materiais.length === 0 ? (
            <Text>Nenhum material cadastrado.</Text>
          ) : (
            materiais.map((material) => (
              <MaterialCard
                key={material.id} 
                material={material}
                onOpen={() => navigation.navigate("Aula", { material })}
                onEdit={() => navigation.navigate("EditMaterial", { material })}
                onDelete={() => handleDelete(material.id, material.titulo)}
              />

            ))
          )}
        </ScrollView>
      </View>

      
      <View style={{
        position: "absolute",
        bottom: 20,
        right: 20,
      }}>
        <LogoutButton onPress={() => navigation.replace("Login")} />
      </View>

    </View>
  );
}
