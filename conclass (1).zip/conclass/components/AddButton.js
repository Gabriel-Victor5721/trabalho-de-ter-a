import { TouchableOpacity, Text, StyleSheet } from "react-native";

export default function AddButton({ onPress }) {
  return (
    <TouchableOpacity style={styles.button} onPress={onPress}>
      <Text style={styles.text}>Adicionar Novo Material</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: "#2196F3",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 10
  },
  text: {
    color: "#FFF",
    fontWeight: "bold",
    fontSize: 16
  }
});
