import { TouchableOpacity, Text, StyleSheet } from 'react-native';

export default function LogoutButton({ onPress }) {
  return (
    <TouchableOpacity style={styles.logout} onPress={onPress}>
      <Text style={styles.text}>Sair</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  logout: {
    backgroundColor: "red",
    paddingVertical: 12,
    paddingHorizontal: 22,
    borderRadius: 30,
  },
  text: {
    color: "#FFF",
    fontWeight: "bold",
    fontSize: 16
  }
});
