import { TouchableOpacity, Text, StyleSheet } from 'react-native';

export default function ButtonPrimary({ text, onPress }) {
  return (
    <TouchableOpacity style={styles.button} onPress={onPress}>
      <Text style={styles.text}>{text}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    backgroundColor: '#4A90E2',
    padding: 14,
    borderRadius: 8,
    alignItems: 'center'
  },
  text: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: 'bold'
  }
});
