import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function Card({ title, description, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.card}>
      <Text style={styles.title}>{title}</Text>
      {description && <Text style={styles.description}>{description}</Text>}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    padding: 16,
    marginVertical: 8,
    borderRadius: 10,
    elevation: 3
  },
  title: {
    fontWeight: 'bold',
    fontSize: 18
  },
  description: {
    marginTop: 5,
    color: '#555'
  }
});
