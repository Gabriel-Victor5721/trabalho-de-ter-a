import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

export default function MaterialCard({ material, onOpen, onEdit, onDelete }) {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>{material.titulo}</Text>
      <Text style={styles.description}>{material.descricao}</Text>

      <View style={styles.buttonsRow}>
        
        <TouchableOpacity style={styles.openButton} onPress={onOpen}>
          <Text style={styles.buttonText}>Abrir</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.editButton} onPress={onEdit}>
          <Text style={styles.buttonText}>Editar</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.deleteButton} onPress={onDelete}>
          <Text style={styles.buttonText}>Excluir</Text>
        </TouchableOpacity>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    padding: 16,
    marginVertical: 10,
    borderRadius: 10,
    elevation: 3,
  },
  title: {
    fontWeight: 'bold',
    fontSize: 20,
  },
  description: {
    marginTop: 8,
    color: '#444',
  },
  buttonsRow: {
    flexDirection: 'row',
    marginTop: 15,
    justifyContent: 'space-between',
  },
  openButton: {
    backgroundColor: '#3498db',
    padding: 10,
    borderRadius: 8,
    marginRight: 5,
  },
  editButton: {
    backgroundColor: '#f1c40f',
    padding: 10,
    borderRadius: 8,
    marginHorizontal: 5,
  },
  deleteButton: {
    backgroundColor: '#e74c3c',
    padding: 10,
    borderRadius: 8,
    marginLeft: 5,
  },
  buttonText: {
    color: '#FFF',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});
