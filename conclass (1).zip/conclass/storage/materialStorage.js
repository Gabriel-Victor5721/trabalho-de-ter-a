import AsyncStorage from "@react-native-async-storage/async-storage";

const STORAGE_KEY = "materiais";

// Buscar todos os materiais
export async function obterMateriais() {
  const json = await AsyncStorage.getItem(STORAGE_KEY);
  return json ? JSON.parse(json) : [];
}

// Salvar novo material
export async function salvarMaterial(material) {
  const lista = await obterMateriais();
  lista.push(material);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(lista));
}

// REMOVER material
export async function removerMaterial(id) {
  let lista = await obterMateriais();
  lista = lista.filter(item => item.id !== id);
  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(lista));
}

// ⭐ ATUALIZAR MATERIAL (FUNÇÃO DO BOTÃO SALVAR)
export async function atualizarMaterial(id, novoTitulo, novaDescricao) {
  let lista = await obterMateriais();

  lista = lista.map(item =>
    item.id === id
      ? { ...item, titulo: novoTitulo, descricao: novaDescricao }
      : item
  );

  await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(lista));
}
